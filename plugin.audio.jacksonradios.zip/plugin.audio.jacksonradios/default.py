import xbmcgui
import xbmcplugin
import sys
import urllib.request
import re

URL_LISTA = "https://github.com/ytjackson/r-dios-m3u-e-add-on-kodi/raw/refs/heads/main/radios.m3u"

def get_data(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        response = urllib.request.urlopen(req)
        return response.read().decode('utf-8')
    except: return ""

def main():
    handle = int(sys.argv[1])
    content = get_data(URL_LISTA)
    
    # Pega o parâmetro 'folder' da URL para saber se estamos na raiz ou dentro de um grupo
    param_string = sys.argv[2][1:]
    params = dict(urllib.parse.parse_qsl(param_string))
    target_group = params.get('group')

    # Expressão regular para capturar logo, grupo, nome e link
    pattern = r'#EXTINF:.*tvg-logo="(.*?)".*group-title="(.*?)",(.*?)\n(.*?)$'
    matches = re.findall(pattern, content, re.MULTILINE)

    if not target_group:
        # MODO RAIZ: Mostra as pastas dos grupos
        grupos = sorted(list(set([m[1] for m in matches])))
        for g in grupos:
            list_item = xbmcgui.ListItem(label=f"📂 {g}")
            url = f"{sys.argv[0]}?group={urllib.parse.quote(g)}"
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=True)
    else:
        # MODO GRUPO: Mostra os canais daquele grupo selecionado
        for logo, grupo, nome, url in matches:
            if grupo == target_group:
                list_item = xbmcgui.ListItem(label=nome.strip())
                list_item.setArt({'icon': logo, 'thumb': logo})
                xbmcplugin.addDirectoryItem(handle=handle, url=url.strip(), listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    main()
